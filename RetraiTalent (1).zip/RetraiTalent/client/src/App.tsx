import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Profile from "@/pages/profile";
import Interview from "@/pages/interview";
import JobPosting from "@/pages/job-posting";
import CandidateProfile from "@/pages/candidate-profile";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-neon-green border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      {/* Authenticated routes */}
      {isAuthenticated ? (
        <>
          {user?.role === "recruiter" ? (
            // --- Recruiter Routes ---
            <>
              {/* FIX: Add the /dashboard route for recruiters */}
              <Route path="/dashboard" component={Dashboard} />
              {/* FIX: Point the root route to the dashboard as well */}
              <Route path="/" component={Dashboard} />
              <Route path="/job/:jobId" component={JobPosting} />
              <Route path="/candidate/:candidateId" component={CandidateProfile} />
            </>
          ) : (
            // --- Job Seeker Routes ---
            <>
              <Route path="/" component={Dashboard} />
              <Route path="/dashboard" component={Dashboard} />
              <Route path="/profile" component={Profile} />
              <Route path="/interview" component={Interview} />
            </>
          )}
        </>
      ) : (
        // --- Unauthenticated Route ---
        <Route path="/" component={Landing} />
      )}

      {/* Fallback for any other route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
