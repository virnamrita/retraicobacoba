import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import Header from "@/components/layout/header";
import CandidateCard from "@/components/candidate-card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Users, Calendar, Eye, Filter } from "lucide-react";
import type { JobPosting, Candidate } from "@shared/schema";

export default function JobPosting() {
  const params = useParams();
  const jobId = params.jobId || "marketing-specialist-001";

  const { data: jobPosting, isLoading: isLoadingJob } = useQuery<JobPosting>({
    queryKey: ["/api/job-posting", jobId],
  });

  const { data: candidates = [], isLoading: isLoadingCandidates } = useQuery<Candidate[]>({
    queryKey: ["/api/candidates"],
  });

  if (isLoadingJob || isLoadingCandidates) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!jobPosting) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-charcoal">Job posting not found</h2>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Job Title Section */}
      <div className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center space-x-3 mb-4">
            <button 
              onClick={() => window.history.back()} 
              className="text-charcoal hover:text-neon-green transition-colors"
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="text-gray-500">Jobs</span>
            <span className="text-gray-400">/</span>
            <span className="text-charcoal font-medium" data-testid="text-job-title-breadcrumb">
              {jobPosting.title}
            </span>
          </div>
          <h1 className="text-3xl font-bold text-charcoal mb-2" data-testid="text-job-title">
            {jobPosting.title}
          </h1>
          <div className="flex flex-wrap items-center gap-4 text-gray-600">
            <span className="flex items-center" data-testid="text-applications-count">
              <Users className="w-4 h-4 mr-2 text-neon-green" />
              {jobPosting.applicationsCount} Applications
            </span>
            <span className="flex items-center" data-testid="text-posted-date">
              <Calendar className="w-4 h-4 mr-2 text-neon-green" />
              Posted {jobPosting.postedDaysAgo} days ago
            </span>
            <span className="flex items-center" data-testid="text-views-count">
              <Eye className="w-4 h-4 mr-2 text-neon-green" />
              {jobPosting.viewsCount} Views
            </span>
          </div>
        </div>
      </div>

      {/* Candidates List */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-charcoal" data-testid="text-candidates-heading">
            Candidate Applications
          </h2>
          <div className="flex items-center space-x-4">
            <Select>
              <SelectTrigger className="border-cool-gray text-charcoal focus:ring-neon-green w-[180px]" data-testid="select-sort">
                <SelectValue placeholder="Sort by: Latest" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="latest">Sort by: Latest</SelectItem>
                <SelectItem value="experience">Sort by: Experience</SelectItem>
                <SelectItem value="salary">Sort by: Salary</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              className="bg-neon-green text-white hover:bg-neon-green-dark"
              data-testid="button-filter"
            >
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>

        {/* Candidate Cards */}
        <div className="space-y-4" data-testid="list-candidates">
          {candidates.map((candidate) => (
            <CandidateCard key={candidate.id} candidate={candidate} />
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button 
            variant="outline" 
            className="border-neon-green text-neon-green hover:bg-neon-green hover:text-white"
            data-testid="button-load-more"
          >
            Load More Candidates
          </Button>
        </div>
      </div>
    </div>
  );
}
