import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Play, 
  Square,
  ArrowLeft,
  Check
} from "lucide-react";
import { Link } from "wouter";

export default function Interview() {
  const { user } = useAuth();
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [isMicOn, setIsMicOn] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isInterviewStarted, setIsInterviewStarted] = useState(false);
  const [isInterviewCompleted, setIsInterviewCompleted] = useState(false);

  const interviewQuestions = [
    "Tell me about yourself and your professional background.",
    "What motivated you to apply for this position?",
    "Describe a challenging project you worked on and how you overcame obstacles.",
    "Where do you see yourself in the next 5 years?",
    "Why should we hire you for this role?"
  ];

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      setStream(mediaStream);
      setIsCameraOn(true);
      setIsMicOn(true);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      toast({
        title: "Camera Access Error",
        description: "Unable to access camera and microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const toggleCamera = () => {
    if (stream) {
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsCameraOn(videoTrack.enabled);
      }
    }
  };

  const toggleMicrophone = () => {
    if (stream) {
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMicOn(audioTrack.enabled);
      }
    }
  };

  const startInterview = () => {
    setIsInterviewStarted(true);
    setIsRecording(true);
    toast({
      title: "Interview Started",
      description: "Good luck! Take your time to answer each question thoughtfully.",
    });
  };

  const nextQuestion = () => {
    if (currentQuestion < interviewQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      completeInterview();
    }
  };

  const completeInterview = () => {
    setIsRecording(false);
    setIsInterviewCompleted(true);
    toast({
      title: "Interview Completed!",
      description: "Thank you for completing your video interview. We'll review your responses and get back to you soon.",
    });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/profile">
                <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="button-back-profile">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Profile
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-charcoal">AI Interview</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!isInterviewCompleted ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Video Preview */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-charcoal" data-testid="text-video-preview-title">
                    <Video className="w-5 h-5 mr-2 text-neon-green" />
                    Video Preview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video mb-4">
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      className="w-full h-full object-cover"
                      data-testid="video-preview"
                    />
                    {!isCameraOn && (
                      <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                        <VideoOff className="w-16 h-16 text-gray-400" />
                      </div>
                    )}
                    
                    {/* Recording indicator */}
                    {isRecording && (
                      <div className="absolute top-4 left-4 flex items-center space-x-2 bg-red-600 text-white px-3 py-1 rounded-full">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium">Recording</span>
                      </div>
                    )}
                  </div>

                  {/* Camera Controls */}
                  <div className="flex justify-center space-x-4">
                    <Button
                      variant="outline"
                      onClick={toggleCamera}
                      className={`${isCameraOn ? 'border-green-500 text-green-600' : 'border-red-500 text-red-600'}`}
                      data-testid="button-toggle-camera"
                    >
                      {isCameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                    </Button>
                    
                    <Button
                      variant="outline"
                      onClick={toggleMicrophone}
                      className={`${isMicOn ? 'border-green-500 text-green-600' : 'border-red-500 text-red-600'}`}
                      data-testid="button-toggle-mic"
                    >
                      {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Interview Panel */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-charcoal" data-testid="text-interview-panel-title">
                    {!isInterviewStarted ? "Ready to Start?" : `Question ${currentQuestion + 1} of ${interviewQuestions.length}`}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {!isInterviewStarted ? (
                    <div className="space-y-4">
                      <p className="text-gray-600" data-testid="text-interview-instructions">
                        You're about to start your AI-powered video interview. Make sure:
                      </p>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li className="flex items-center">
                          <Check className="w-4 h-4 text-neon-green mr-2" />
                          Camera and microphone are working
                        </li>
                        <li className="flex items-center">
                          <Check className="w-4 h-4 text-neon-green mr-2" />
                          You're in a quiet environment
                        </li>
                        <li className="flex items-center">
                          <Check className="w-4 h-4 text-neon-green mr-2" />
                          Good lighting on your face
                        </li>
                        <li className="flex items-center">
                          <Check className="w-4 h-4 text-neon-green mr-2" />
                          Stable internet connection
                        </li>
                      </ul>
                      
                      <Button
                        onClick={startInterview}
                        className="w-full bg-neon-green text-white hover:bg-neon-green-dark"
                        disabled={!isCameraOn || !isMicOn}
                        data-testid="button-start-now"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Start Now
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="p-4 bg-neon-green/10 rounded-lg border border-neon-green/20">
                        <p className="text-charcoal font-medium mb-2">Question:</p>
                        <p className="text-gray-700" data-testid="text-current-question">
                          {interviewQuestions[currentQuestion]}
                        </p>
                      </div>
                      
                      <div className="text-sm text-gray-600">
                        <p>Take your time to think about your answer. Click "Next Question" when you're ready to continue.</p>
                      </div>

                      <Button
                        onClick={nextQuestion}
                        className="w-full bg-neon-green text-white hover:bg-neon-green-dark"
                        data-testid="button-next-question"
                      >
                        {currentQuestion < interviewQuestions.length - 1 ? "Next Question" : "Complete Interview"}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Progress */}
              {isInterviewStarted && (
                <Card className="mt-6">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-charcoal">Progress</span>
                      <span className="text-sm text-gray-600">{currentQuestion + 1} of {interviewQuestions.length}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-neon-green h-2 rounded-full transition-all duration-300"
                        style={{ width: `${((currentQuestion + 1) / interviewQuestions.length) * 100}%` }}
                      ></div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        ) : (
          /* Interview Completed */
          <div className="text-center py-16">
            <Card className="max-w-2xl mx-auto">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-6">
                  <Check className="w-10 h-10 text-white" />
                </div>
                
                <h2 className="text-3xl font-bold text-charcoal mb-4" data-testid="text-interview-complete">
                  Interview Complete!
                </h2>
                
                <p className="text-gray-600 mb-8" data-testid="text-completion-message">
                  Great job! Your video interview has been successfully recorded and submitted. 
                  Our AI will analyze your responses and recruiters will be able to view your interview when considering your application.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/dashboard">
                    <Button className="bg-neon-green text-white hover:bg-neon-green-dark" data-testid="button-go-dashboard">
                      Go to Dashboard
                    </Button>
                  </Link>
                  
                  <Link href="/profile">
                    <Button variant="outline" className="border-neon-green text-neon-green hover:bg-neon-green hover:text-white" data-testid="button-back-profile-complete">
                      Back to Profile
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}