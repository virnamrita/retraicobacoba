import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <header className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl font-bold text-charcoal">Retrai</h1>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="button-login">
                  Login
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-neon-green text-white hover:bg-neon-green-dark" data-testid="button-signup">
                  Sign up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-5xl font-bold text-charcoal leading-tight" data-testid="text-hero-title">
                Create your live profile and grab your opportunities
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed" data-testid="text-hero-description">
                Stand out from the crowd with video interviews. Show your personality, skills, and passion to recruiters in a way that traditional resumes can't capture.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/register">
                <Button 
                  className="bg-neon-green text-white hover:bg-neon-green-dark text-lg px-8 py-3 w-full sm:w-auto"
                  data-testid="button-get-started"
                >
                  Get Started Free
                </Button>
              </Link>
              <Link href="/login">
                <Button 
                  variant="outline" 
                  className="border-neon-green text-neon-green hover:bg-neon-green hover:text-white text-lg px-8 py-3 w-full sm:w-auto"
                  data-testid="button-login-hero"
                >
                  Already have an account?
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-cool-gray">
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-green" data-testid="text-stat-jobs">500+</div>
                <div className="text-gray-600">Active Jobs</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-green" data-testid="text-stat-companies">100+</div>
                <div className="text-gray-600">Companies</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-neon-green" data-testid="text-stat-candidates">1K+</div>
                <div className="text-gray-600">Job Seekers</div>
              </div>
            </div>
          </div>

          {/* Right Column - Video Preview */}
          <div className="relative">
            <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video" data-testid="video-preview">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450"
                alt="Professional woman smiling during video interview"
                className="w-full h-full object-cover"
                data-testid="img-hero-video"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  className="w-20 h-20 bg-neon-green rounded-full flex items-center justify-center hover:bg-neon-green-dark transition-colors"
                  data-testid="button-play-demo"
                >
                  <Play className="w-8 h-8 text-white ml-1" />
                </button>
              </div>
              <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded text-sm">
                Demo Interview
              </div>
            </div>
            
            {/* Feature callouts */}
            <div className="absolute -top-4 -right-4 bg-white rounded-lg shadow-lg p-4 border border-cool-gray">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                <span className="text-sm font-medium text-charcoal">Live Recording</span>
              </div>
            </div>
            
            <div className="absolute -bottom-4 -left-4 bg-white rounded-lg shadow-lg p-4 border border-cool-gray">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                <span className="text-sm font-medium text-charcoal">AI-Powered</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-charcoal mb-4" data-testid="text-features-title">
              Why Choose Retrai?
            </h2>
            <p className="text-xl text-gray-600" data-testid="text-features-subtitle">
              The future of job applications is here
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6" data-testid="feature-video">
              <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-4">
                <Play className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal mb-2">Video Profiles</h3>
              <p className="text-gray-600">Show your personality and communication skills through video interviews</p>
            </div>
            
            <div className="text-center p-6" data-testid="feature-ai">
              <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z"/>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-charcoal mb-2">AI-Powered Matching</h3>
              <p className="text-gray-600">Get matched with the right opportunities based on your skills and experience</p>
            </div>
            
            <div className="text-center p-6" data-testid="feature-instant">
              <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd"/>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-charcoal mb-2">Instant Applications</h3>
              <p className="text-gray-600">Apply to jobs instantly with your video profile and get faster responses</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}