import { useAuth, useCandidates, useJobPosting } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  User,
  FileText,
  Search,
  Settings,
  Calendar,
  TrendingUp,
  Eye,
  MessageSquare,
  Briefcase,
  Users,
  BarChart2,
  PlusCircle,
  AlertTriangle
} from "lucide-react";
import { Link } from "wouter";
import type { User as UserType, Candidate } from "@shared/schema";

// --- Recruiter Dashboard Component ---
function RecruiterDashboard({ user }: { user: UserType }) {
  const { candidates, isLoading: isLoadingCandidates, error: candidatesError } = useCandidates();
  const { jobPosting, isLoading: isLoadingJob, error: jobError } = useJobPosting("marketing-specialist-001");

  // Log errors to the console for easier debugging.
  if (candidatesError) {
    console.error("Error fetching candidates:", candidatesError);
  }
  if (jobError) {
    console.error("Error fetching job posting:", jobError);
  }

  // If there's an error fetching data, display a helpful message instead of a blank screen.
  if (candidatesError || jobError) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-600">Could Not Load Dashboard</h2>
          <p className="text-gray-600 mt-2">
            There was a problem fetching data from the server. Please try again later.
          </p>
          <p className="text-xs text-gray-400 mt-4">
            (Check the browser's developer console for more technical details)
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold text-charcoal">Retrai (Recruiter)</h1>
              <nav className="hidden md:flex space-x-6">
                <Button variant="ghost" className="text-charcoal hover:text-neon-green">
                  <Briefcase className="w-4 h-4 mr-2" />
                  Job Postings
                </Button>
                <Button variant="ghost" className="text-charcoal hover:text-neon-green">
                  <Users className="w-4 h-4 mr-2" />
                  Candidates
                </Button>
                 <Button variant="ghost" className="text-charcoal hover:text-neon-green">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <img
                src={user.profileImage || `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100`}
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover"
              />
              <span className="text-charcoal font-medium">{user.name}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
            <div>
                <h2 className="text-3xl font-bold text-charcoal">
                    Welcome back, {user.name?.split(' ')[0]}!
                </h2>
                <p className="text-gray-600">
                    Manage your job postings and review candidates.
                </p>
            </div>
            <Button className="bg-neon-green text-white hover:bg-neon-green-dark">
                <PlusCircle className="w-4 h-4 mr-2" />
                Post a New Job
            </Button>
        </div>

        {/* Job Posting Stats */}
        {isLoadingJob && <p>Loading job details...</p>}
        {jobPosting && (
            <Card className="mb-8">
                <CardHeader>
                    <CardTitle className="text-charcoal">{jobPosting.title}</CardTitle>
                    <CardDescription>Current performance for this job posting.</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <Eye className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Total Views</p>
                            <p className="text-2xl font-bold text-charcoal">{jobPosting.viewsCount}</p>
                        </div>
                    </div>
                    <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <FileText className="w-6 h-6 text-green-600" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Total Applications</p>
                            <p className="text-2xl font-bold text-charcoal">{jobPosting.applicationsCount}</p>
                        </div>
                    </div>
                     <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <BarChart2 className="w-6 h-6 text-purple-600" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Conversion Rate</p>
                            <p className="text-2xl font-bold text-charcoal">
                              {jobPosting.viewsCount > 0 ? ((jobPosting.applicationsCount / jobPosting.viewsCount) * 100).toFixed(1) : '0.0'}%
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        )}

        {/* Candidates Table */}
        <Card>
            <CardHeader>
                <CardTitle className="text-charcoal">Candidates for Marketing Specialist</CardTitle>
            </CardHeader>
            <CardContent>
                {isLoadingCandidates && <p className="text-center py-4">Loading candidates...</p>}
                <div className="space-y-4">
                    {candidates && candidates.length > 0 ? (
                        candidates.map((candidate: Candidate) => (
                            <Link key={candidate.id} href={`/candidate/${candidate.id}`}>
                                <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-100 cursor-pointer">
                                    <div className="flex items-center space-x-4">
                                        <img src={candidate.profileImage} alt={candidate.name} className="w-12 h-12 rounded-full object-cover" />
                                        <div>
                                            <p className="font-bold text-charcoal">{candidate.name}</p>
                                            <p className="text-sm text-gray-600">{candidate.currentPosition}</p>
                                        </div>
                                    </div>
                                    <Badge variant={candidate.status === 'Under Review' ? 'default' : 'secondary'}>{candidate.status}</Badge>
                                </div>
                            </Link>
                        ))
                    ) : (
                        !isLoadingCandidates && <p className="text-gray-500 text-center py-4">No candidates have applied for this job yet.</p>
                    )}
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

// --- Job Seeker Dashboard Component ---
function JobSeekerDashboard({ user }: { user: UserType }) {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold text-charcoal">Retrai</h1>
              <nav className="hidden md:flex space-x-6">
                <Link href="/profile">
                  <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="nav-profile">
                    <User className="w-4 h-4 mr-2" />
                    Profile
                  </Button>
                </Link>
                <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="nav-applications">
                  <FileText className="w-4 h-4 mr-2" />
                  Applications
                </Button>
                <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="nav-find-jobs">
                  <Search className="w-4 h-4 mr-2" />
                  Find Jobs
                </Button>
                <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="nav-settings">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <img
                src={user.profileImage || `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100`}
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover"
                data-testid="img-user-profile"
              />
              <span className="text-charcoal font-medium" data-testid="text-user-name">{user.name}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-charcoal mb-2" data-testid="text-welcome">
            Welcome back, {user.name?.split(' ')[0]}!
          </h2>
          <p className="text-gray-600" data-testid="text-dashboard-subtitle">
            Here's what's happening with your job search
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-md transition-shadow" data-testid="card-profile-views">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Profile Views</p>
                  <p className="text-2xl font-bold text-charcoal">24</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Eye className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow" data-testid="card-applications">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Applications</p>
                  <p className="text-2xl font-bold text-charcoal">8</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <FileText className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow" data-testid="card-interviews">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Interviews</p>
                  <p className="text-2xl font-bold text-charcoal">3</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow" data-testid="card-response-rate">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Response Rate</p>
                  <p className="text-2xl font-bold text-charcoal">75%</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-charcoal" data-testid="text-quick-actions-title">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link href="/profile">
                  <Button
                    variant="outline"
                    className="w-full justify-start border-neon-green text-neon-green hover:bg-neon-green hover:text-white"
                    data-testid="button-complete-profile"
                  >
                    <User className="w-4 h-4 mr-3" />
                    Complete Your Profile
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-browse-jobs"
                >
                  <Search className="w-4 h-4 mr-3" />
                  Browse New Jobs
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-practice-interview"
                >
                  <MessageSquare className="w-4 h-4 mr-3" />
                  Practice Interview
                </Button>
              </CardContent>
            </Card>
            {/* Recent Activity */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-charcoal" data-testid="text-recent-activity-title">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg" data-testid="activity-item-1">
                    <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm text-charcoal">Applied to Marketing Specialist at TechCorp</p>
                      <p className="text-xs text-gray-500">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg" data-testid="activity-item-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm text-charcoal">Profile viewed by StartupHub</p>
                      <p className="text-xs text-gray-500">1 day ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg" data-testid="activity-item-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm text-charcoal">Completed video interview</p>
                      <p className="text-xs text-gray-500">3 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Profile Completion */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-charcoal" data-testid="text-profile-completion-title">Profile Completion</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-charcoal">Overall Progress</span>
                    <span className="text-sm font-bold text-neon-green">60%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-neon-green h-2 rounded-full w-3/5"></div>
                  </div>
                  <div className="space-y-3 mt-6">
                    <div className="flex items-center justify-between" data-testid="completion-basic-info">
                      <span className="text-sm text-gray-600">Basic Information</span>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">Complete</Badge>
                    </div>
                    <div className="flex items-center justify-between" data-testid="completion-cv">
                      <span className="text-sm text-gray-600">CV Upload</span>
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Pending</Badge>
                    </div>
                    <div className="flex items-center justify-between" data-testid="completion-interview">
                      <span className="text-sm text-gray-600">Video Interview</span>
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Pending</Badge>
                    </div>
                    <div className="flex items-center justify-between" data-testid="completion-experience">
                      <span className="text-sm text-gray-600">Work Experience</span>
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Pending</Badge>
                    </div>
                  </div>
                  <Link href="/profile">
                    <Button className="w-full bg-neon-green text-white hover:bg-neon-green-dark mt-4" data-testid="button-update-profile">
                      Update Profile
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
            {/* Recommended Jobs */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-charcoal" data-testid="text-recommended-jobs-title">Recommended Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 border border-cool-gray rounded-lg hover:bg-gray-50 cursor-pointer" data-testid="job-recommendation-1">
                    <h4 className="font-medium text-charcoal">Digital Marketing Specialist</h4>
                    <p className="text-sm text-gray-600">TechStart Inc.</p>
                    <p className="text-sm text-neon-green font-medium">$70,000 - $85,000</p>
                  </div>
                  <div className="p-3 border border-cool-gray rounded-lg hover:bg-gray-50 cursor-pointer" data-testid="job-recommendation-2">
                    <h4 className="font-medium text-charcoal">Content Marketing Manager</h4>
                    <p className="text-sm text-gray-600">Creative Agency</p>
                    <p className="text-sm text-neon-green font-medium">$65,000 - $80,000</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4 border-neon-green text-neon-green hover:bg-neon-green hover:text-white" data-testid="button-view-all-jobs">
                  View All Jobs
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Main Dashboard Component ---
export default function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    // You might want to show a loading spinner here
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (user.role === 'recruiter') {
    return <RecruiterDashboard user={user} />;
  }

  // Default to job seeker dashboard
  return <JobSeekerDashboard user={user} />;
}
