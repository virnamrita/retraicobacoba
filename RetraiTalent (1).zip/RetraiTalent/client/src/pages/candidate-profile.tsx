import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import Header from "@/components/layout/header";
import VideoPlayer from "@/components/ui/video-player";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  ArrowLeft, 
  Calendar, 
  Download, 
  Mail, 
  Phone, 
  Linkedin,
  CheckCircle,
  XCircle
} from "lucide-react";
import type { Candidate, WorkExperience } from "@shared/schema";

export default function CandidateProfile() {
  const params = useParams();
  const candidateId = params.candidateId;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: candidate, isLoading: isLoadingCandidate } = useQuery<Candidate>({
    queryKey: ["/api/candidates", candidateId],
    enabled: !!candidateId,
  });

  const { data: experience = [], isLoading: isLoadingExperience } = useQuery<WorkExperience[]>({
    queryKey: ["/api/candidates", candidateId, "experience"],
    enabled: !!candidateId,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      await apiRequest(`/api/candidates/${candidateId}/status`, "PUT", { status });
    },
    onSuccess: (_, status) => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidates", candidateId] });
      queryClient.invalidateQueries({ queryKey: ["/api/candidates"] });
      toast({
        title: "Status Updated",
        description: `Candidate ${status === "Shortlisted" ? "shortlisted" : "rejected"} successfully`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update candidate status",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Shortlisted": return "bg-green-100 text-green-800";
      case "Rejected": return "bg-red-100 text-red-800";
      default: return "bg-yellow-100 text-yellow-800";
    }
  };

  if (isLoadingCandidate || isLoadingExperience) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-6 bg-gray-200 rounded w-1/3"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-charcoal">Candidate not found</h2>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Breadcrumb */}
      <div className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-3">
            <Link href="/">
              <button className="text-charcoal hover:text-neon-green transition-colors" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </button>
            </Link>
            <span className="text-gray-500">Marketing Specialist</span>
            <span className="text-gray-400">/</span>
            <span className="text-charcoal font-medium" data-testid="text-candidate-breadcrumb">
              {candidate.name}
            </span>
          </div>
        </div>
      </div>

      {/* Profile Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Profile Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-6 mb-6">
                  <img
                    src={candidate.profileImage}
                    alt={`${candidate.name} profile`}
                    className="w-24 h-24 rounded-full object-cover"
                    data-testid="img-candidate-profile"
                  />
                  <div className="flex-1">
                    <h1 className="text-2xl font-bold text-charcoal mb-2" data-testid="text-candidate-name">
                      {candidate.name}
                    </h1>
                    <p className="text-lg text-gray-600 mb-1" data-testid="text-candidate-position">
                      {candidate.currentPosition}
                    </p>
                    <p className="text-gray-500 mb-4" data-testid="text-candidate-company">
                      {candidate.currentCompany}
                    </p>
                    <div className="flex flex-wrap gap-4 mb-4">
                      <Button className="bg-neon-green text-white hover:bg-neon-green-dark" data-testid="button-schedule-interview">
                        <Calendar className="w-4 h-4 mr-2" />
                        Schedule Interview
                      </Button>
                      <Button variant="outline" className="border-neon-green text-neon-green hover:bg-neon-green hover:text-white" data-testid="button-download-resume">
                        <Download className="w-4 h-4 mr-2" />
                        Download Resume
                      </Button>
                    </div>
                    <div className="flex gap-3">
                      <Button
                        variant="outline"
                        className="border-green-500 text-green-600 hover:bg-green-50"
                        onClick={() => updateStatusMutation.mutate("Shortlisted")}
                        disabled={updateStatusMutation.isPending || candidate.status === "Shortlisted"}
                        data-testid="button-shortlist-candidate"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Shortlist Candidate
                      </Button>
                      <Button
                        variant="outline"
                        className="border-red-500 text-red-600 hover:bg-red-50"
                        onClick={() => updateStatusMutation.mutate("Rejected")}
                        disabled={updateStatusMutation.isPending || candidate.status === "Rejected"}
                        data-testid="button-reject-candidate"
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Reject Candidate
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Video Interview */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-charcoal mb-4" data-testid="text-interview-heading">
                  Interview
                </h3>
                <VideoPlayer 
                  thumbnailUrl={candidate.videoInterviewUrl}
                  title="Candidate Interview"
                />
              </CardContent>
            </Card>

            {/* Work Experience */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-charcoal mb-6" data-testid="text-experience-heading">
                  Work Experience
                </h3>
                <div className="space-y-6">
                  {experience.map((exp, index) => (
                    <div key={exp.id} className="flex space-x-4" data-testid={`experience-${index}`}>
                      <div className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full ${exp.isCurrent ? 'bg-neon-green' : 'bg-gray-300'}`}></div>
                        {index < experience.length - 1 && (
                          <div className="w-px h-full bg-cool-gray mt-2"></div>
                        )}
                      </div>
                      <div className="flex-1 pb-6">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-charcoal" data-testid={`text-job-title-${index}`}>
                            {exp.jobTitle}
                          </h4>
                          <span className="text-sm text-gray-500" data-testid={`text-duration-${index}`}>
                            {exp.startYear} - {exp.endYear || 'Present'}
                          </span>
                        </div>
                        <p className="text-gray-600 mb-2" data-testid={`text-company-${index}`}>
                          {exp.company}
                        </p>
                        <p className="text-gray-700 text-sm leading-relaxed mb-3" data-testid={`text-description-${index}`}>
                          {exp.description}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {exp.skills.map((skill, skillIndex) => (
                            <Badge 
                              key={skillIndex} 
                              variant="secondary" 
                              className="text-xs"
                              data-testid={`badge-skill-${index}-${skillIndex}`}
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Info */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-charcoal mb-4" data-testid="text-contact-heading">
                  Contact Information
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3" data-testid="contact-email">
                    <Mail className="w-4 h-4 text-neon-green" />
                    <span className="text-gray-700">{candidate.email}</span>
                  </div>
                  <div className="flex items-center space-x-3" data-testid="contact-phone">
                    <Phone className="w-4 h-4 text-neon-green" />
                    <span className="text-gray-700">{candidate.phone}</span>
                  </div>
                  <div className="flex items-center space-x-3" data-testid="contact-linkedin">
                    <Linkedin className="w-4 h-4 text-neon-green" />
                    <span className="text-gray-700">{candidate.linkedin}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Skills */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-charcoal mb-4" data-testid="text-skills-heading">
                  Key Skills
                </h3>
                <div className="flex flex-wrap gap-2">
                  {['Digital Marketing', 'SEO/SEM', 'Social Media', 'Analytics', 'Content Strategy', 'Team Leadership'].map((skill, index) => (
                    <Badge 
                      key={index} 
                      className="bg-neon-green/10 text-neon-green border-neon-green/20"
                      data-testid={`badge-key-skill-${index}`}
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Application Details */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-charcoal mb-4" data-testid="text-application-heading">
                  Application Details
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between" data-testid="detail-applied">
                    <span className="text-gray-600">Applied</span>
                    <span className="text-charcoal font-medium">
                      {candidate.appliedDaysAgo} day{candidate.appliedDaysAgo !== 1 ? 's' : ''} ago
                    </span>
                  </div>
                  <div className="flex justify-between" data-testid="detail-salary">
                    <span className="text-gray-600">Expected Salary</span>
                    <span className="text-charcoal font-medium">
                      ${candidate.expectedSalary.toLocaleString()}/month
                    </span>
                  </div>
                  <div className="flex justify-between" data-testid="detail-availability">
                    <span className="text-gray-600">Availability</span>
                    <span className="text-charcoal font-medium">{candidate.availability}</span>
                  </div>
                  <div className="flex justify-between" data-testid="detail-status">
                    <span className="text-gray-600">Status</span>
                    <Badge variant="secondary" className={getStatusColor(candidate.status)}>
                      {candidate.status}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
