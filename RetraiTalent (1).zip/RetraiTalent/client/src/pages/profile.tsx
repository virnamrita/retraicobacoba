import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth, useLogout } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  User, 
  Upload, 
  Plus, 
  Edit, 
  Trash2, 
  Save,
  LogOut,
  ArrowLeft,
  Video
} from "lucide-react";
import { Link, useLocation } from "wouter";
import type { WorkExperience, ProfileData } from "@shared/schema";

interface ExperienceForm {
  jobTitle: string;
  company: string;
  startYear: number;
  endYear: number | null;
  description: string;
  skills: string[];
  isCurrent: boolean;
}

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const logoutMutation = useLogout();
  const [, setLocation] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Profile form state
  const [profileData, setProfileData] = useState<ProfileData>({
    name: user?.name || "",
    phone: user?.phone || "",
    email: user?.email || "",
    domicile: user?.domicile || "",
    expectedSalary: user?.expectedSalary || 0,
  });

  // Experience form state
  const [showExperienceForm, setShowExperienceForm] = useState(false);
  const [editingExperience, setEditingExperience] = useState<string | null>(null);
  const [experienceForm, setExperienceForm] = useState<ExperienceForm>({
    jobTitle: "",
    company: "",
    startYear: new Date().getFullYear(),
    endYear: null,
    description: "",
    skills: [],
    isCurrent: false,
  });

  // Fetch user work experience
  const { data: experience = [], isLoading: isLoadingExperience } = useQuery<WorkExperience[]>({
    queryKey: ["/api/experience"],
    enabled: !!user,
  });

  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileData) => {
      return await apiRequest("/api/profile", "PUT", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  // Experience mutations
  const addExperienceMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/experience", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experience"] });
      setShowExperienceForm(false);
      resetExperienceForm();
      toast({
        title: "Experience Added",
        description: "Work experience has been added successfully",
      });
    },
  });

  const updateExperienceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return await apiRequest(`/api/experience/${id}`, "PUT", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experience"] });
      setEditingExperience(null);
      resetExperienceForm();
      toast({
        title: "Experience Updated",
        description: "Work experience has been updated successfully",
      });
    },
  });

  const deleteExperienceMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/experience/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experience"] });
      toast({
        title: "Experience Deleted",
        description: "Work experience has been deleted successfully",
      });
    },
  });

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(profileData);
  };

  const handleExperienceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const data = {
      ...experienceForm,
      endYear: experienceForm.isCurrent ? null : experienceForm.endYear,
    };

    if (editingExperience) {
      updateExperienceMutation.mutate({ id: editingExperience, data });
    } else {
      addExperienceMutation.mutate(data);
    }
  };

  const resetExperienceForm = () => {
    setExperienceForm({
      jobTitle: "",
      company: "",
      startYear: new Date().getFullYear(),
      endYear: null,
      description: "",
      skills: [],
      isCurrent: false,
    });
    setShowExperienceForm(false);
    setEditingExperience(null);
  };

  const startEditingExperience = (exp: WorkExperience) => {
    setExperienceForm({
      jobTitle: exp.jobTitle,
      company: exp.company,
      startYear: exp.startYear,
      endYear: exp.endYear,
      description: exp.description,
      skills: exp.skills,
      isCurrent: exp.isCurrent,
    });
    setEditingExperience(exp.id);
    setShowExperienceForm(true);
  };

  const handleCVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real implementation, this would upload to a file storage service
      toast({
        title: "CV Upload",
        description: "CV upload functionality would be implemented here with file storage service",
      });
    }
  };

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      setLocation("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to logout",
        variant: "destructive",
      });
    }
  };

  const addSkill = (skill: string) => {
    if (skill.trim() && !experienceForm.skills.includes(skill.trim())) {
      setExperienceForm(prev => ({
        ...prev,
        skills: [...prev.skills, skill.trim()]
      }));
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setExperienceForm(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill !== skillToRemove)
    }));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-cool-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" className="text-charcoal hover:text-neon-green" data-testid="button-back-dashboard">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-charcoal">My Profile</h1>
            </div>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              className="text-red-600 border-red-300 hover:bg-red-50"
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Basic Information */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center text-charcoal" data-testid="text-basic-info-title">
              <User className="w-5 h-5 mr-2 text-neon-green" />
              Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                    className="border-cool-gray focus:ring-neon-green"
                    data-testid="input-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={profileData.phone}
                    onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                    className="border-cool-gray focus:ring-neon-green"
                    data-testid="input-phone"
                  />
                </div>
                
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                    className="border-cool-gray focus:ring-neon-green"
                    data-testid="input-email"
                  />
                </div>
                
                <div>
                  <Label htmlFor="domicile">Domicile</Label>
                  <Input
                    id="domicile"
                    value={profileData.domicile}
                    onChange={(e) => setProfileData(prev => ({ ...prev, domicile: e.target.value }))}
                    className="border-cool-gray focus:ring-neon-green"
                    data-testid="input-domicile"
                  />
                </div>
                
                <div>
                  <Label htmlFor="expectedSalary">Expected Monthly Salary</Label>
                  <Input
                    id="expectedSalary"
                    type="number"
                    value={profileData.expectedSalary}
                    onChange={(e) => setProfileData(prev => ({ ...prev, expectedSalary: parseInt(e.target.value) || 0 }))}
                    className="border-cool-gray focus:ring-neon-green"
                    data-testid="input-salary"
                  />
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="bg-neon-green text-white hover:bg-neon-green-dark"
                disabled={updateProfileMutation.isPending}
                data-testid="button-save-profile"
              >
                <Save className="w-4 h-4 mr-2" />
                {updateProfileMutation.isPending ? "Saving..." : "Save Profile"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Interview Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center text-charcoal" data-testid="text-interview-title">
              <Video className="w-5 h-5 mr-2 text-neon-green" />
              Interview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="cv-upload">Submit CV</Label>
              <div className="mt-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleCVUpload}
                  className="hidden"
                  data-testid="input-cv-file"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="border-neon-green text-neon-green hover:bg-neon-green hover:text-white"
                  data-testid="button-upload-cv"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Upload CV (PDF, DOC, DOCX)
                </Button>
              </div>
              <p className="text-sm text-gray-500 mt-2">
                Our AI will analyze your CV and automatically fill in your work experience
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Experience Section */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-charcoal" data-testid="text-experience-title">Experience</CardTitle>
              <Button
                onClick={() => setShowExperienceForm(true)}
                className="bg-neon-green text-white hover:bg-neon-green-dark"
                data-testid="button-add-experience"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Experience
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Experience Form */}
            {showExperienceForm && (
              <Card className="mb-6 border-neon-green">
                <CardContent className="p-6">
                  <form onSubmit={handleExperienceSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="jobTitle">Job Title</Label>
                        <Input
                          id="jobTitle"
                          value={experienceForm.jobTitle}
                          onChange={(e) => setExperienceForm(prev => ({ ...prev, jobTitle: e.target.value }))}
                          required
                          data-testid="input-job-title"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="company">Company</Label>
                        <Input
                          id="company"
                          value={experienceForm.company}
                          onChange={(e) => setExperienceForm(prev => ({ ...prev, company: e.target.value }))}
                          required
                          data-testid="input-company"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="startYear">Start Year</Label>
                        <Input
                          id="startYear"
                          type="number"
                          value={experienceForm.startYear}
                          onChange={(e) => setExperienceForm(prev => ({ ...prev, startYear: parseInt(e.target.value) }))}
                          required
                          data-testid="input-start-year"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="endYear">End Year</Label>
                        <Input
                          id="endYear"
                          type="number"
                          value={experienceForm.endYear || ""}
                          onChange={(e) => setExperienceForm(prev => ({ ...prev, endYear: e.target.value ? parseInt(e.target.value) : null }))}
                          disabled={experienceForm.isCurrent}
                          data-testid="input-end-year"
                        />
                        <div className="flex items-center mt-2">
                          <input
                            type="checkbox"
                            id="isCurrent"
                            checked={experienceForm.isCurrent}
                            onChange={(e) => setExperienceForm(prev => ({ ...prev, isCurrent: e.target.checked }))}
                            className="mr-2"
                            data-testid="checkbox-current"
                          />
                          <Label htmlFor="isCurrent" className="text-sm">Currently working here</Label>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Job Description</Label>
                      <Textarea
                        id="description"
                        value={experienceForm.description}
                        onChange={(e) => setExperienceForm(prev => ({ ...prev, description: e.target.value }))}
                        rows={4}
                        required
                        data-testid="textarea-description"
                      />
                    </div>
                    
                    <div>
                      <Label>Skills</Label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {experienceForm.skills.map((skill, index) => (
                          <Badge key={index} variant="secondary" className="bg-neon-green/10 text-neon-green">
                            {skill}
                            <button
                              type="button"
                              onClick={() => removeSkill(skill)}
                              className="ml-2 text-red-500 hover:text-red-700"
                            >
                              ×
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <Input
                        placeholder="Add a skill and press Enter"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            addSkill(e.currentTarget.value);
                            e.currentTarget.value = '';
                          }
                        }}
                        data-testid="input-skills"
                      />
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        type="submit" 
                        className="bg-neon-green text-white hover:bg-neon-green-dark"
                        disabled={addExperienceMutation.isPending || updateExperienceMutation.isPending}
                        data-testid="button-save-experience"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        {editingExperience ? "Update" : "Add"} Experience
                      </Button>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={resetExperienceForm}
                        data-testid="button-cancel-experience"
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            {/* Experience List */}
            <div className="space-y-4">
              {isLoadingExperience ? (
                <div className="text-center py-8">Loading experience...</div>
              ) : experience.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No work experience added yet. Click "Add Experience" to get started.
                </div>
              ) : (
                experience.map((exp, index) => (
                  <Card key={exp.id} className="border-cool-gray" data-testid={`experience-item-${index}`}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-semibold text-charcoal text-lg">{exp.jobTitle}</h3>
                          <p className="text-gray-600 mb-2">{exp.company}</p>
                          <p className="text-sm text-gray-500 mb-3">
                            {exp.startYear} - {exp.endYear || 'Present'}
                          </p>
                          <p className="text-gray-700 mb-3">{exp.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {exp.skills.map((skill, skillIndex) => (
                              <Badge key={skillIndex} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => startEditingExperience(exp)}
                            data-testid={`button-edit-experience-${index}`}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deleteExperienceMutation.mutate(exp.id)}
                            disabled={deleteExperienceMutation.isPending}
                            className="text-red-600 hover:bg-red-50"
                            data-testid={`button-delete-experience-${index}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Start Interview Button */}
            {experience.length > 0 && (
              <div className="mt-8 text-center">
                <Link href="/interview">
                  <Button 
                    className="bg-neon-green text-white hover:bg-neon-green-dark text-lg px-8 py-3"
                    data-testid="button-start-interview"
                  >
                    <Video className="w-5 h-5 mr-2" />
                    Save profile and start free interview
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}