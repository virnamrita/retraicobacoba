import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { User, LoginData, RegisterData, Candidate, JobPosting } from "@shared/schema";

export function useAuth() {
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ["/api/me"],
    retry: false,
  });

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
  };
}

export function useLogin() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: LoginData) => {
      return await apiRequest("/api/login", "POST", data);
    },
    onSuccess: (user) => {
      queryClient.setQueryData(["/api/me"], user);
    },
  });
}

export function useRegister() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: RegisterData) => {
      return await apiRequest("/api/register", "POST", data);
    },
    onSuccess: (user) => {
      queryClient.setQueryData(["/api/me"], user);
    },
  });
}

export function useLogout() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/logout", "POST");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/me"], null);
      queryClient.clear();
    },
  });
}

// --- Data Fetching Hooks for Recruiter Dashboard ---

/**
 * Custom hook to fetch all candidates.
 * @returns {object} The candidates data, loading state, and error state.
 */
export function useCandidates() {
  const { data, isLoading, error } = useQuery<Candidate[]>({
    queryKey: ["/api/candidates"],
    queryFn: () => apiRequest("/api/candidates", "GET"),
  });
  return { candidates: data, isLoading, error };
}

/**
 * Custom hook to fetch a single job posting by its ID.
 * @param {string} jobId - The ID of the job posting to fetch.
 * @returns {object} The job posting data, loading state, and error state.
 */
export function useJobPosting(jobId: string) {
  const { data, isLoading, error } = useQuery<JobPosting>({
    queryKey: ["/api/job-posting", jobId],
    queryFn: () => apiRequest(`/api/job-posting/${jobId}`, "GET"),
    enabled: !!jobId, // The query will only run if a non-empty jobId is provided.
  });
  return { jobPosting: data, isLoading, error };
}
