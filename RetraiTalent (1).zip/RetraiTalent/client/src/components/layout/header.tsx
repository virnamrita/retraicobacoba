import { Bell } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-white border-b border-cool-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <h1 className="text-2xl font-bold text-charcoal">Retrai</h1>
            <nav className="hidden md:flex space-x-6">
              <a href="#" className="text-charcoal hover:text-neon-green transition-colors">
                Dashboard
              </a>
              <a href="#" className="text-charcoal hover:text-neon-green transition-colors">
                Jobs
              </a>
              <a href="#" className="text-charcoal hover:text-neon-green transition-colors">
                Analytics
              </a>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              className="p-2 text-charcoal hover:text-neon-green transition-colors"
              data-testid="button-notifications"
            >
              <Bell className="w-5 h-5" />
            </button>
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
              alt="Recruiter profile"
              className="w-8 h-8 rounded-full object-cover"
              data-testid="img-profile"
            />
          </div>
        </div>
      </div>
    </header>
  );
}
