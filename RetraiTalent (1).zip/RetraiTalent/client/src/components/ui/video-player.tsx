import { useState } from "react";
import { Play } from "lucide-react";

interface VideoPlayerProps {
  thumbnailUrl: string;
  videoUrl?: string;
  duration?: string;
  title?: string;
}

export default function VideoPlayer({ 
  thumbnailUrl, 
  videoUrl, 
  duration = "3:45",
  title = "Interview Video"
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = () => {
    if (videoUrl) {
      // In a real implementation, this would integrate with a video player
      setIsPlaying(true);
    } else {
      // Mock implementation for demonstration
      alert("Video player would start here. In a real implementation, this would integrate with a video player library.");
    }
  };

  return (
    <div className="relative bg-gray-900 rounded-lg overflow-hidden" data-testid="video-player">
      <img
        src={thumbnailUrl}
        alt={title}
        className="w-full h-64 object-cover"
        data-testid="img-video-thumbnail"
      />
      {!isPlaying && (
        <>
          <div className="absolute inset-0 flex items-center justify-center">
            <button
              onClick={handlePlay}
              className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center hover:bg-neon-green-dark transition-colors"
              data-testid="button-play-video"
            >
              <Play className="w-6 h-6 text-white ml-1" />
            </button>
          </div>
          <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded text-sm">
            {duration}
          </div>
        </>
      )}
    </div>
  );
}
