import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Clock, CheckCircle, XCircle } from "lucide-react";
import { Link } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Candidate } from "@shared/schema";

interface CandidateCardProps {
  candidate: Candidate;
}

export default function CandidateCard({ candidate }: CandidateCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      await apiRequest(`/api/candidates/${candidate.id}/status`, "PUT", { status });
    },
    onSuccess: (_, status) => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidates"] });
      toast({
        title: "Status Updated",
        description: `Candidate ${status === "Shortlisted" ? "shortlisted" : "rejected"} successfully`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update candidate status",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Shortlisted": return "bg-green-100 text-green-800";
      case "Rejected": return "bg-red-100 text-red-800";
      default: return "bg-yellow-100 text-yellow-800";
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow" data-testid={`card-candidate-${candidate.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-4">
            <img
              src={candidate.profileImage}
              alt={`${candidate.name} profile`}
              className="w-16 h-16 rounded-full object-cover"
              data-testid={`img-candidate-${candidate.id}`}
            />
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <h3 className="text-lg font-semibold text-charcoal" data-testid={`text-name-${candidate.id}`}>
                  {candidate.name}
                </h3>
                <Badge 
                  variant="secondary" 
                  className={getStatusColor(candidate.status)}
                  data-testid={`badge-status-${candidate.id}`}
                >
                  {candidate.status}
                </Badge>
              </div>
              <p className="text-gray-600 mb-1" data-testid={`text-position-${candidate.id}`}>
                {candidate.currentPosition}
              </p>
              <p className="text-gray-500 text-sm mb-3" data-testid={`text-company-${candidate.id}`}>
                {candidate.currentCompany}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <span className="flex items-center text-gray-600" data-testid={`text-salary-${candidate.id}`}>
                  <DollarSign className="w-4 h-4 mr-1 text-neon-green" />
                  ${candidate.expectedSalary.toLocaleString()}/month expected
                </span>
                <span className="flex items-center text-gray-600" data-testid={`text-applied-${candidate.id}`}>
                  <Clock className="w-4 h-4 mr-1 text-neon-green" />
                  Applied {candidate.appliedDaysAgo} day{candidate.appliedDaysAgo !== 1 ? 's' : ''} ago
                </span>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <Link href={`/candidate/${candidate.id}`}>
              <Button 
                className="bg-neon-green text-white hover:bg-neon-green-dark whitespace-nowrap w-full"
                data-testid={`button-profile-${candidate.id}`}
              >
                See complete profile
              </Button>
            </Link>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="border-green-500 text-green-600 hover:bg-green-50"
                onClick={() => updateStatusMutation.mutate("Shortlisted")}
                disabled={updateStatusMutation.isPending || candidate.status === "Shortlisted"}
                data-testid={`button-shortlist-${candidate.id}`}
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Shortlist
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-red-500 text-red-600 hover:bg-red-50"
                onClick={() => updateStatusMutation.mutate("Rejected")}
                disabled={updateStatusMutation.isPending || candidate.status === "Rejected"}
                data-testid={`button-reject-${candidate.id}`}
              >
                <XCircle className="w-4 h-4 mr-1" />
                Reject
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
