import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("jobseeker"), // "recruiter" or "jobseeker"
  name: text("name"),
  phone: text("phone"),
  domicile: text("domicile"),
  expectedSalary: integer("expected_salary"),
  cvUrl: text("cv_url"),
  profileImage: text("profile_image"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const jobPostings = pgTable("job_postings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  applicationsCount: integer("applications_count").default(0),
  viewsCount: integer("views_count").default(0),
  postedDaysAgo: integer("posted_days_ago").default(0),
});

export const candidates = pgTable("candidates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  currentPosition: text("current_position").notNull(),
  currentCompany: text("current_company").notNull(),
  expectedSalary: integer("expected_salary").notNull(),
  appliedDaysAgo: integer("applied_days_ago").notNull(),
  profileImage: text("profile_image").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  linkedin: text("linkedin").notNull(),
  videoInterviewUrl: text("video_interview_url").notNull(),
  availability: text("availability").notNull(),
  status: text("status").notNull().default("Under Review"), // "Under Review", "Shortlisted", "Rejected"
});

export const workExperience = pgTable("work_experience", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(), // Reference to users table for jobseekers
  candidateId: varchar("candidate_id"), // Reference to candidates table for applications
  jobTitle: text("job_title").notNull(),
  company: text("company").notNull(),
  startYear: integer("start_year").notNull(),
  endYear: integer("end_year"),
  description: text("description").notNull(),
  skills: text("skills").array().notNull(),
  isCurrent: boolean("is_current").default(false),
});

export const interviews = pgTable("interviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  videoUrl: text("video_url"),
  transcript: text("transcript"),
  status: text("status").notNull().default("pending"), // "pending", "completed", "failed"
  createdAt: timestamp("created_at").defaultNow(),
});

export const applications = pgTable("applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  jobPostingId: varchar("job_posting_id").notNull(),
  status: text("status").notNull().default("applied"), // "applied", "shortlisted", "rejected"
  appliedAt: timestamp("applied_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const loginSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
});

export const registerSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  role: true,
  name: true,
});

export const profileSchema = createInsertSchema(users).pick({
  name: true,
  phone: true,
  email: true,
  domicile: true,
  expectedSalary: true,
});

export const insertJobPostingSchema = createInsertSchema(jobPostings).omit({
  id: true,
});

export const insertCandidateSchema = createInsertSchema(candidates).omit({
  id: true,
});

export const insertWorkExperienceSchema = createInsertSchema(workExperience).omit({
  id: true,
});

export const insertInterviewSchema = createInsertSchema(interviews).omit({
  id: true,
  createdAt: true,
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  appliedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;
export type ProfileData = z.infer<typeof profileSchema>;
export type JobPosting = typeof jobPostings.$inferSelect;
export type Candidate = typeof candidates.$inferSelect;
export type WorkExperience = typeof workExperience.$inferSelect;
export type Interview = typeof interviews.$inferSelect;
export type Application = typeof applications.$inferSelect;
export type InsertJobPosting = z.infer<typeof insertJobPostingSchema>;
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;
export type InsertWorkExperience = z.infer<typeof insertWorkExperienceSchema>;
export type InsertInterview = z.infer<typeof insertInterviewSchema>;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
