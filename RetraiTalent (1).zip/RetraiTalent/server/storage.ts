import {
  type User,
  type InsertUser,
  type LoginData,
  type RegisterData,
  type ProfileData,
  type JobPosting,
  type Candidate,
  type WorkExperience,
  type Interview,
  type Application,
  type InsertWorkExperience,
  users,
  jobPostings,
  candidates,
  workExperience,
  interviews,
  applications
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, sql, inArray } from "drizzle-orm"; // Corrected: Changed 'In' to 'inArray'
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IStorage {
  // Auth methods
  register(data: RegisterData): Promise<User>;
  login(data: LoginData): Promise<User | null>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  updateProfile(userId: string, data: ProfileData): Promise<User>;
  uploadCV(userId: string, cvUrl: string): Promise<User>;

  // Job and candidate methods
  getJobPosting(id: string): Promise<JobPosting | undefined>;
  getAllCandidates(): Promise<Candidate[]>;
  getCandidate(id: string): Promise<Candidate | undefined>;
  updateCandidateStatus(candidateId: string, status: string): Promise<Candidate>;

  // Work experience methods
  getWorkExperienceByCandidate(candidateId: string): Promise<WorkExperience[]>;
  getWorkExperienceByUser(userId: string): Promise<WorkExperience[]>;
  addWorkExperience(data: InsertWorkExperience): Promise<WorkExperience>;
  updateWorkExperience(id: string, data: Partial<InsertWorkExperience>): Promise<WorkExperience>;
  deleteWorkExperience(id: string): Promise<void>;

  // Interview methods
  createInterview(userId: string): Promise<Interview>;
  updateInterview(id: string, data: Partial<Interview>): Promise<Interview>;
  getInterviewByUser(userId: string): Promise<Interview | undefined>;
}

export class DatabaseStorage implements IStorage {
  // This promise will resolve when the database is initialized.
  private initializationPromise: Promise<void>;

  constructor() {
    // Start the initialization process, but don't block the constructor.
    this.initializationPromise = this.initializeData();
  }

  private async initializeData(): Promise<void> {
    try {
      // --- Create or Update Demo Users (Robust Method) ---
      // This section now ensures the demo users are always correct by deleting and re-creating them on every start.
      console.log("Resetting and synchronizing demo user accounts...");

      // 1. Delete existing demo accounts to ensure a clean slate.
      await db.delete(users).where(inArray(users.email, ["recruiter@demo.com", "jobseeker@demo.com"]));

      // 2. Create fresh demo accounts with correctly hashed passwords.
      const hashedPassword = await bcrypt.hash("demo123", 10);
      const demoUsers: InsertUser[] = [
        {
          id: 'recruiter-demo-01',
          name: 'Recruiter Demo',
          email: 'recruiter@demo.com',
          password: hashedPassword,
          role: 'recruiter',
        },
        {
          id: 'jobseeker-demo-01',
          name: 'Job Seeker Demo',
          email: 'jobseeker@demo.com',
          password: hashedPassword,
          role: 'jobseeker',
        },
      ];
      await db.insert(users).values(demoUsers);
      console.log("Demo user accounts synchronized successfully.");


      // --- Create Sample Job Posting and Candidates ---
      // Check if sample data already exists to avoid recreating it.
      const existingJob = await db.select().from(jobPostings).limit(1);
      if (existingJob.length > 0) return;

      console.log("Creating sample job posting and candidates...");
      // Create sample job posting
      const [jobPost] = await db.insert(jobPostings).values({
        id: "marketing-specialist-001",
        title: "Marketing Specialist",
        description: "Looking for an experienced marketing specialist to join our growing team.",
        applicationsCount: 24,
        viewsCount: 156,
        postedDaysAgo: 5,
      }).returning();

      // Create sample candidates
      const candidateData = [
        {
          id: "sarah-johnson",
          name: "Sarah Johnson",
          currentPosition: "Senior Marketing Manager",
          currentCompany: "TechCorp Solutions",
          expectedSalary: 85000,
          appliedDaysAgo: 2,
          profileImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          email: "sarah.johnson@email.com",
          phone: "+1 (555) 123-4567",
          linkedin: "linkedin.com/in/sarah-johnson",
          videoInterviewUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
          availability: "Immediate",
          status: "Under Review",
        },
        {
          id: "michael-chen",
          name: "Michael Chen",
          currentPosition: "Digital Marketing Specialist",
          currentCompany: "Creative Agency Inc.",
          expectedSalary: 72000,
          appliedDaysAgo: 3,
          profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          email: "michael.chen@email.com",
          phone: "+1 (555) 234-5678",
          linkedin: "linkedin.com/in/michael-chen",
          videoInterviewUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
          availability: "2 weeks notice",
          status: "Under Review",
        },
        {
          id: "emily-rodriguez",
          name: "Emily Rodriguez",
          currentPosition: "Marketing Coordinator",
          currentCompany: "StartupHub",
          expectedSalary: 68000,
          appliedDaysAgo: 4,
          profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          email: "emily.rodriguez@email.com",
          phone: "+1 (555) 345-6789",
          linkedin: "linkedin.com/in/emily-rodriguez",
          videoInterviewUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
          availability: "Immediate",
          status: "Under Review",
        },
        {
          id: "david-thompson",
          name: "David Thompson",
          currentPosition: "Brand Marketing Manager",
          currentCompany: "Global Brands Co.",
          expectedSalary: 78000,
          appliedDaysAgo: 5,
          profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          email: "david.thompson@email.com",
          phone: "+1 (555) 456-7890",
          linkedin: "linkedin.com/in/david-thompson",
          videoInterviewUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
          availability: "1 month notice",
          status: "Under Review",
        },
        {
          id: "lisa-wang",
          name: "Lisa Wang",
          currentPosition: "Content Marketing Lead",
          currentCompany: "Media Dynamics",
          expectedSalary: 82000,
          appliedDaysAgo: 7,
          profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200&q=80",
          email: "lisa.wang@email.com",
          phone: "+1 (555) 567-8901",
          linkedin: "linkedin.com/in/lisa-wang",
          videoInterviewUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450",
          availability: "Immediate",
          status: "Under Review",
        },
      ];

      await db.insert(candidates).values(candidateData);

      // Create sample work experience for Sarah Johnson
      const sarahExperience = [
        {
          userId: "jobseeker-demo-01", // Link experience to the job seeker demo account
          candidateId: "sarah-johnson",
          jobTitle: "Senior Marketing Manager",
          company: "TechCorp Solutions",
          startYear: 2022,
          endYear: null,
          description: "Led cross-functional marketing initiatives that increased brand awareness by 40%. Managed a team of 5 marketing specialists and oversaw digital campaigns with budgets exceeding $500K annually.",
          skills: ["Digital Marketing", "Team Leadership", "Brand Strategy"],
          isCurrent: true,
        },
        {
          userId: "jobseeker-demo-01", // Link experience to the job seeker demo account
          candidateId: "sarah-johnson",
          jobTitle: "Marketing Specialist",
          company: "Growth Dynamics Inc.",
          startYear: 2020,
          endYear: 2022,
          description: "Developed and executed social media strategies that grew follower engagement by 65%. Collaborated with design teams to create compelling visual content for multiple campaigns.",
          skills: ["Social Media", "Content Creation", "Analytics"],
          isCurrent: false,
        },
      ];

      await db.insert(workExperience).values(sarahExperience);
      console.log("Sample job data created successfully.");
    } catch (error) {
      console.error("Error initializing sample data:", error);
    }
  }

  // Auth methods
  async register(data: RegisterData): Promise<User> {
    await this.initializationPromise;
    const hashedPassword = await bcrypt.hash(data.password, 10);
    const [user] = await db.insert(users).values({
      ...data,
      password: hashedPassword,
    }).returning();
    return user;
  }

  async login(data: LoginData): Promise<User | null> {
    await this.initializationPromise;
    const [user] = await db.select().from(users).where(eq(users.email, data.email));

    if (!user) {
      return null;
    }

    const isValid = await bcrypt.compare(data.password, user.password);
    return isValid ? user : null;
  }

  async getUserById(id: string): Promise<User | undefined> {
    await this.initializationPromise;
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    await this.initializationPromise;
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async updateProfile(userId: string, data: ProfileData): Promise<User> {
    await this.initializationPromise;
    const [user] = await db.update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async uploadCV(userId: string, cvUrl: string): Promise<User> {
    await this.initializationPromise;
    const [user] = await db.update(users)
      .set({ cvUrl, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Job and candidate methods
  async getJobPosting(id: string): Promise<JobPosting | undefined> {
    await this.initializationPromise;
    const [jobPosting] = await db.select().from(jobPostings).where(eq(jobPostings.id, id));
    return jobPosting;
  }

  async getAllCandidates(): Promise<Candidate[]>;
  async getCandidate(id: string): Promise<Candidate | undefined> {
    await this.initializationPromise;
    const [candidate] = await db.select().from(candidates).where(eq(candidates.id, id));
    return candidate;
  }

  async updateCandidateStatus(candidateId: string, status: string): Promise<Candidate> {
    await this.initializationPromise;
    const [candidate] = await db.update(candidates)
      .set({ status })
      .where(eq(candidates.id, candidateId))
      .returning();
    return candidate;
  }

  // Work experience methods
  async getWorkExperienceByCandidate(candidateId: string): Promise<WorkExperience[]> {
    await this.initializationPromise;
    return await db.select().from(workExperience)
      .where(eq(workExperience.candidateId, candidateId))
      .orderBy(workExperience.startYear);
  }

  async getWorkExperienceByUser(userId: string): Promise<WorkExperience[]> {
    await this.initializationPromise;
    return await db.select().from(workExperience)
      .where(eq(workExperience.userId, userId))
      .orderBy(workExperience.startYear);
  }

  async addWorkExperience(data: InsertWorkExperience): Promise<WorkExperience> {
    await this.initializationPromise;
    const [experience] = await db.insert(workExperience).values(data).returning();
    return experience;
  }

  async updateWorkExperience(id: string, data: Partial<InsertWorkExperience>): Promise<WorkExperience> {
    await this.initializationPromise;
    const [experience] = await db.update(workExperience)
      .set(data)
      .where(eq(workExperience.id, id))
      .returning();
    return experience;
  }

  async deleteWorkExperience(id: string): Promise<void> {
    await this.initializationPromise;
    await db.delete(workExperience).where(eq(workExperience.id, id));
  }

  // Interview methods
  async createInterview(userId: string): Promise<Interview> {
    await this.initializationPromise;
    const [interview] = await db.insert(interviews).values({ userId }).returning();
    return interview;
  }

  async updateInterview(id: string, data: Partial<Interview>): Promise<Interview> {
    await this.initializationPromise;
    const [interview] = await db.update(interviews)
      .set(data)
      .where(eq(interviews.id, id))
      .returning();
    return interview;
  }

  async getInterviewByUser(userId: string): Promise<Interview | undefined> {
    await this.initializationPromise;
    const [interview] = await db.select().from(interviews).where(eq(interviews.userId, userId));
    return interview;
  }
}

export const storage = new DatabaseStorage();
