import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { loginSchema, registerSchema, profileSchema, insertWorkExperienceSchema } from "@shared/schema";

// Extend the express-session interface to include our custom userId property.
// This provides type safety for req.session.userId.
declare module 'express-session' {
  interface SessionData {
    userId?: string;
  }
}

// Authentication middleware to protect routes.
// It checks if a userId exists in the session. If not, it denies access.
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  if (!req.session.userId) {
    // If no userId is found in the session, return a 401 Unauthorized error.
    return res.status(401).json({ message: "Authentication required" });
  }
  // If authenticated, proceed to the next middleware or route handler.
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware setup. This should ideally be at the top level of your app,
  // but is placed here to work with the existing structure.
  app.use(session({
    secret: process.env.SESSION_SECRET || 'a-very-strong-secret-key', // It's important to use an environment variable for the secret.
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production', // Set to true in production with HTTPS for security.
      httpOnly: true, // Prevents client-side JS from accessing the cookie.
      maxAge: 24 * 60 * 60 * 1000 // Cookie expires after 24 hours.
    }
  }));

  // --- Authentication Routes ---

  // Route for user registration.
  app.post("/api/register", async (req, res) => {
    try {
      // Validate the request body against the registration schema.
      const data = registerSchema.parse(req.body);

      // Check if a user with the given email already exists to prevent duplicates.
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(409).json({ message: "A user with this email already exists" }); // 409 Conflict is more specific here.
      }

      // Create the new user in the database.
      const user = await storage.register(data);
      // Store the new user's ID in the session to log them in immediately.
      req.session.userId = user.id;

      // Remove the password from the user object before sending it in the response.
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword); // 201 Created is the standard for successful resource creation.
    } catch (error: any) {
      // Handle validation errors or other issues.
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  // Route for user login.
  app.post("/api/login", async (req, res) => {
    try {
      // Validate the request body against the login schema.
      const data = loginSchema.parse(req.body);
      // Attempt to log the user in with the provided credentials.
      const user = await storage.login(data);

      // If login fails (e.g., wrong password), storage.login should return null.
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // If login is successful, store the user's ID in the session.
      req.session.userId = user.id;

      // Remove the password from the user object before sending the response.
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error: any) {
      // Handle validation errors or other issues.
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  // Route for user logout.
  app.post("/api/logout", (req, res) => {
    // Destroy the session to log the user out.
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out due to a server error" });
      }
      // Clear the session cookie from the browser.
      res.clearCookie('connect.sid'); // 'connect.sid' is the default session cookie name for express-session.
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Route to get the currently authenticated user's data.
  app.get("/api/me", requireAuth, async (req, res) => {
    try {
      // The requireAuth middleware ensures req.session.userId is set.
      const user = await storage.getUserById(req.session.userId!);
      if (!user) {
        // This case might happen if the user was deleted but the session still exists.
        return res.status(404).json({ message: "User not found" });
      }

      // Remove password from the response for security.
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch user data" });
    }
  });

  // --- Profile Routes ---

  app.put("/api/profile", requireAuth, async (req, res) => {
    try {
      const data = profileSchema.parse(req.body);
      const user = await storage.updateProfile(req.session.userId!, data);

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Profile update failed" });
    }
  });

  // --- Work Experience Routes ---

  app.get("/api/experience", requireAuth, async (req, res) => {
    try {
      const experience = await storage.getWorkExperienceByUser(req.session.userId!);
      res.json(experience);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch work experience" });
    }
  });

  app.post("/api/experience", requireAuth, async (req, res) => {
    try {
      const data = insertWorkExperienceSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      const experience = await storage.addWorkExperience(data);
      res.json(experience);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to add work experience" });
    }
  });

  app.put("/api/experience/:id", requireAuth, async (req, res) => {
    try {
      const experience = await storage.updateWorkExperience(req.params.id, req.body);
      res.json(experience);
    } catch (error) {
      res.status(500).json({ message: "Failed to update work experience" });
    }
  });

  app.delete("/api/experience/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteWorkExperience(req.params.id);
      res.json({ message: "Work experience deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete work experience" });
    }
  });

  // --- Interview Routes ---

  app.post("/api/interview", requireAuth, async (req, res) => {
    try {
      const interview = await storage.createInterview(req.session.userId!);
      res.json(interview);
    } catch (error) {
      res.status(500).json({ message: "Failed to create interview" });
    }
  });

  app.get("/api/interview", requireAuth, async (req, res) => {
    try {
      const interview = await storage.getInterviewByUser(req.session.userId!);
      res.json(interview || { status: "not_started" });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch interview" });
    }
  });

  // --- Job and Candidate Routes (Public or for other roles) ---

  app.get("/api/job-posting/:id", async (req, res) => {
    try {
      const jobPosting = await storage.getJobPosting(req.params.id);
      if (!jobPosting) {
        return res.status(404).json({ message: "Job posting not found" });
      }
      res.json(jobPosting);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job posting" });
    }
  });

  app.get("/api/candidates", async (req, res) => {
    try {
      const candidates = await storage.getAllCandidates();
      res.json(candidates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch candidates" });
    }
  });

  app.get("/api/candidates/:id", async (req, res) => {
    try {
      const candidate = await storage.getCandidate(req.params.id);
      if (!candidate) {
        return res.status(404).json({ message: "Candidate not found" });
      }
      res.json(candidate);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch candidate" });
    }
  });

  app.put("/api/candidates/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const candidate = await storage.updateCandidateStatus(req.params.id, status);
      res.json(candidate);
    } catch (error) {
      res.status(500).json({ message: "Failed to update candidate status" });
    }
  });

  app.get("/api/candidates/:id/experience", async (req, res) => {
    try {
      const experience = await storage.getWorkExperienceByCandidate(req.params.id);
      res.json(experience);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch work experience" });
    }
  });

  // Create and return the HTTP server instance.
  const httpServer = createServer(app);
  return httpServer;
}


