import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { loginSchema, registerSchema, profileSchema, insertWorkExperienceSchema } from "@shared/schema";

// Extend the express-session interface to include our custom userId property.
declare module 'express-session' {
  interface SessionData {
    userId?: string;
  }
}

// Authentication middleware to protect routes.
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware setup.
  app.use(session({
    secret: process.env.SESSION_SECRET || 'a-very-strong-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // --- Authentication Routes ---

  app.post("/api/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(409).json({ message: "A user with this email already exists" });
      }
      const user = await storage.register(data);
      req.session.userId = user.id;
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      const user = await storage.login(data);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      req.session.userId = user.id;
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out due to a server error" });
      }
      res.clearCookie('connect.sid');
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUserById(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch user data" });
    }
  });

  // --- Profile & Experience Routes (Protected) ---

  app.put("/api/profile", requireAuth, async (req, res) => {
    try {
      const data = profileSchema.parse(req.body);
      const user = await storage.updateProfile(req.session.userId!, data);
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Profile update failed" });
    }
  });

  app.post("/api/experience", requireAuth, async (req, res) => {
    try {
      const data = insertWorkExperienceSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      const experience = await storage.addWorkExperience(data);
      res.json(experience);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to add work experience" });
    }
  });

  // --- Recruiter Data Routes (Protected) ---

  // FIX: Added requireAuth to protect this route
  app.get("/api/job-posting/:id", requireAuth, async (req, res) => {
    try {
      const jobPosting = await storage.getJobPosting(req.params.id);
      if (!jobPosting) {
        return res.status(404).json({ message: "Job posting not found" });
      }
      res.json(jobPosting);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch job posting" });
    }
  });

  // FIX: Added requireAuth to protect this route
  app.get("/api/candidates", requireAuth, async (req, res) => {
    try {
      const candidates = await storage.getAllCandidates();
      res.json(candidates);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch candidates" });
    }
  });

  // FIX: Added requireAuth to protect this route
  app.get("/api/candidates/:id", requireAuth, async (req, res) => {
    try {
      const candidate = await storage.getCandidate(req.params.id);
      if (!candidate) {
        return res.status(404).json({ message: "Candidate not found" });
      }
      res.json(candidate);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch candidate" });
    }
  });

  // Create and return the HTTP server instance.
  const httpServer = createServer(app);
  return httpServer;
}
